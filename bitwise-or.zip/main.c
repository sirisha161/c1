#include<stdio.h>
int main(){
    int a,b,result;
    scanf("%d",&a);
    scanf("%d",&b);
    result=a|b;
    printf("bitwise OR of %d and %d is:%d\n",a,b,result);
    
}