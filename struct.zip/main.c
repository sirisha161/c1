#include <stdio.h>
struct employe{
    int id;
    char name[50];
    char designation[50];
    int age;
    int salary;
    int bonus;
}emp;

int main()
{
 scanf("%d %[^\n]%[^\n]%d%d%d",&emp.id,&emp.name,&emp.designation,&emp.age,&emp.salary,&emp.bonus);

 printf("%d %d %d %d",emp.id,emp.name,emp.designation,emp.age,emp.salary,emp.bonus);

    return 0;
}