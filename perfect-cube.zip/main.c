#include<stdio.h>
#include<math.h>
int is_perfect_cube(int n){
    int cube_root=round(cbrt(n));
    return(cube_root*cube_root*cube_root==n);
}
int main()
{
    int n;
    scanf("%d",&n);
    if(is_perfect_cube(n))
    {
        printf("valid");
    }
    else{
        printf("Not valid");
    }
    return 0;
}