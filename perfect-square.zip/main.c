#include<stdio.h>
#include<math.h>
int main()
{
    int n;
    scanf("%d",&n);
    int root=sqrt(n);
    if(root*root==n){
        printf("valid");
    }
    else{
        printf("not valid");
    }
    return 0;
}
